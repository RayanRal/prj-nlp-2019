As I awoke one morning, when all good things are born  
There was a robin on my window sill to welcome in the dawn.  
He was so small and fragile and sweetly he did sing,  
Of thoughts of joy and happiness into my heart did spring.  
I smiled to myself as I stood beside my bed  
And slowly brought the window down and crushed it's f****** head.
