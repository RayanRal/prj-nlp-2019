<h1>Learning about automated poem generation using Python and a book text file, packaging that pile of random silly text, and placing it on a blog because you got nothing better to do with your time</h1>

Check out this little auto blogging tool, built to push content from a text file, makes some what sensible sentences, and pushes it to wordpress.

I'm attaching a bit of content regarding how to loop it, if you don't want to learn how to build that process in python. Understandable. Maybe just want to stress test your wordpress website? Okay, sure.

Fast forward and skip the muck unless you want to learn python, read the old-read-me.

Here's the steps to automate blogging...

https://github.com/MassiveNoobie/AI-Poetry/blob/master/poemgen-push-to-wordpress

https://github.com/MassiveNoobie/AI-Poetry/blob/master/basic-script-to-launch

https://github.com/MassiveNoobie/AI-Poetry/blob/master/autohotkey-scheduler-looper

Disclaimer, going into abusing a system, you should know ahead of time there is always a balance when posting
I hope you don't get banned and it's likely you will if you use this to SPAM.
Mix up usage of tags. Disclaimer on that below
Have fun!

Contact me here.
 # # # https://tylergarrett.com https://dev3lop.com

Important note...
Use appropriate tags.
Attach appropriate categories and tags to your posts so people can find them in the WordPress.com Reader. But be careful not to use too many tags — less than 15 tags (or categories or both) is a good number. The more tags you use, the less likely your post will be featured in the Reader. Read more on tagging.

Dependencies can be grasped from the final script - https://github.com/MassiveNoobie/AI-Poetry/blob/master/poemgen-push-to-wordpress
It's not much :)

