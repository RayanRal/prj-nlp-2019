- [x] **Heatmap**
* https://www.flickr.com/photos/stevefaeembra/5565448824
* http://kyrandale.com/viz/static/expts/d3-chess-css3d/index_squares.html
* http://en.chessbase.com/post/study-of-square-utilization-and-occupancy

- [x] **Move Paths**
* http://imgur.com/a/pYHyk/layout/grid
* http://archive.turbulence.org/spotlight/thinking/mid-viz.jpg

- [ ] **Survivors**
* https://www.quora.com/What-are-the-chances-of-survival-of-individual-chess-pieces-in-average-games
* http://imgur.com/gallery/c1AhDU3

- [ ] **Maybe?**
* http://rtribbia.com/chessViz/
* http://creative-co.de/random_chess/ - vector fields?
