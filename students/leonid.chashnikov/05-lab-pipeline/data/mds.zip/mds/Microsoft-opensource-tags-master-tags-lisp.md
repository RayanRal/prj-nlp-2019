---
name: lisp
displayName: Lisp
description: Popular programming language
---

Lisp is a family of computer programming languages with a long history and a distinctive, fully parenthesized prefix notation.

