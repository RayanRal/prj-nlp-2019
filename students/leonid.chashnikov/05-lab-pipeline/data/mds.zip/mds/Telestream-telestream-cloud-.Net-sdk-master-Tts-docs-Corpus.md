# Telestream.Cloud.Tts.Model.Corpus
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The name of the Corpus. | [optional] 
**Status** | **string** | Determines the status of the Corpus. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


