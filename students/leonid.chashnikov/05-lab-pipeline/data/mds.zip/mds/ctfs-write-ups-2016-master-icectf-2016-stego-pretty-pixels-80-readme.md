# IceCTF-2016 : pretty-pixels-80

**Category:** Stego
**Points:** 80
**Description:**

Don't get me wrong, I love pretty colors as much as the next guy... but what does it mean? pretty_pixels.png

## Writeup

(TODO)

## Other write-ups and resources

* [0x90r00t](https://0x90r00t.com/2016/08/26/icectf-2016-stega-100-pretty-pixels-write-up/)
* https://github.com/73696e65/ctf-notes/blob/master/2016-IceCTF/Pretty_Pixels-Stego-80.py
* https://github.com/318BR/IceCTF/tree/master/2016/Stage3/Pretty_Pixels
* https://github.com/bburky/mathematica-ctf-writeups/blob/master/Pixel%20data/
* https://www.youtube.com/watch?v=1HZO82tXl_k&feature=youtu.be

