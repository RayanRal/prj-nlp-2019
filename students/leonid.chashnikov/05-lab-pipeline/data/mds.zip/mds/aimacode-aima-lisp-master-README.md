# aima-lisp

Common Lisp implementation of algorithms from Russell And Norvig's book *Artificial Intelligence - A Modern Approach.*

This repository was the original code base, back in 1995. 
Since then, the Java and Python versions have become more popular, and this Lisp version is no
longer up-to-date. But it is here for whatever use you want to make of it.

