chinese-poetry-zhCN
===================

chinese-poetry [古诗] 简体中文版本, **宋词在主仓库就是简体无须转换**.


# build

```
git submodule update --init

pip install -r requirements.txt

python trans.py
```

