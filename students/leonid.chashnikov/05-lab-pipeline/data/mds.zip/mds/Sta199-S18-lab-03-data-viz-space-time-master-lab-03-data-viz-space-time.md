---
title: "Lab 03 - Visualizing spatial data"
author: "INSERT TEAM NAME HERE"
date: "INSERT TODAY'S DATE HERE"
output: 
  html_document: 
    highlight: pygments
    keep_md: yes
---

### Load packages


```r
library(tidyverse) 
```

### Load data


```r
dn <- read_csv("data/dennys.csv")
lq <- read_csv("data/laquinta.csv")
states <- read_csv("data/states.csv")
```

(Add code chunks and narrative as needed below.)

### Exercise 1

### Exercise 2

### Exercise 3

### Exercise 4

### Exercise 5

### Exercise 6

### Exercise 7

### Exercise 8

(Note that the exercises below should use only US data. Make sure to include appropriate code to filter the data for US.)

### Exercise 9

### Exercise 10

### Exercise 11

### Exercise 12

