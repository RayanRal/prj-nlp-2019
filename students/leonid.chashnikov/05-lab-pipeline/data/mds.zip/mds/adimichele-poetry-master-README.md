# Random Poetry Generator

Run with `ruby poetry` or just `rake`. Make sure you install the dependencies with `bundle`.

Configuration options can be specified in `config.yml`. See `config.yml` for more information on those options.

