# In a Station of the Metro

*by Ezra Pound*

The apparition of these faces in the crowd;
 
Petals on a wet, black bough. 

- See more at: [Poets.org](http://www.poets.org/viewmedia.php/prmMID/15421#sthash.rWML6MIu.dpuf)--
ONE MORE LINE?
