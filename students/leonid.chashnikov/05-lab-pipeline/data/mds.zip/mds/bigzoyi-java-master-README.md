# java

##学习任务 
effective java https://github.com/HackathonHackers/programming-ebooks/blob/master/Java/Effective%20Java%20(2nd%20Edition).pdf


##java并发编程
###Java并发编程：Callable、Future和FutureTask
  http://www.cnblogs.com/dolphin0520/p/3949310.html
###Java多线程--让主线程等待所有子线程执行完毕 
  http://www.iteye.com/topic/581476

###finagle(twitter的一个RFC框架)
  example https://github.com/jghoman/finagle-java-example
  
  http://ju.outofmemory.cn/entry/116835
  
  搭建：http://www.bubuko.com/infodetail-521087.html
  
##重要软件

astah-professional：破解版安装 http://bbs.feng.com/read-htm-tid-8907096.html

##java开源电子商城系统

###基于 OFBiz 的电商平台 BigFish
http://bigfish.solveda.com/bfDownload.html

http://www.apache.org/dyn/closer.lua/ofbiz/apache-ofbiz-13.07.03.zip

###收费
The Apache OFBiz™ Project
Java开源网店系统 SHOP++
Java商场系统 JEShop
网上商店系统 JAVASHOP
多用户Java商城系统 LegendShop
Java商城网店软件 TurboShop
电子商务平台 faceCart
宠物商店 PetStore
Web销售管理系统 Shopizer
在线商城系统 jshoper（ostocy-jshop）
Web应用框架 Pulse-java
Kgmall 金刚多用户商城系统 kgMall
Java 的网店系统(B2C) jeeshop
Java 电子商务软件 Broadleaf
电子商务应用程序 Smilehouse Workspace

###成神之路

http://www.hollischuang.com/archives/489

###JVM
http://www.cnblogs.com/smyhvae/p/4810168.html

http://www.cnblogs.com/kongzhongqijing/articles/3625340.html


