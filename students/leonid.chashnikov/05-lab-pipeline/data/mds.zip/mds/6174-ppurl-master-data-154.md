## 皮皮书屋电驴下载资源 

**Beginning XML ,4th Edition.pdf** (ed2k://|file|Beginning%20XML%20%2C4th%20Edition.pdf|19950443|f9be4874ff6e25299fa4cfdd54fb88e2|h=uxzkitur4ta7xf7dqmxv2jmja2a4ulkn|/)

**Computer Networks and Internets (5th Edition).pdf** (ed2k://|file|Computer%20Networks%20and%20Internets%20%285th%20Edition%29.pdf|4998835|15b6cfebd98778a331f42ee36803b373|h=buhhqgt6ufj2pblonj7xlafamgjtjkrc|/)

**TCP_IP Foundations.pdf** (ed2k://|file|TCP_IP%20Foundations.pdf|7140892|c96cf390ded0a607e272f0b188e1ca6e|h=ah6k32aeza5rwrra5prh7pfkpvdt4teq|/)

**Concurrent Programming.pdf** (ed2k://|file|Concurrent%20Programming.pdf|25358314|83bf6566e7e36b2fad902f503df78b37|h=ovvjsaqr34xhz3xds3qxbxueixblpzpc|/)

**Cisco Network Design Solutions for Small-Medium Businesses.chm** (ed2k://|file|Cisco%20Network%20Design%20Solutions%20for%20Small-Medium%20Businesses.chm|1609675|8520f8383bf09145dbaa0cd8edc74144|h=bawihzwdb5wsa6ef3rkqor3pxcrloguy|/)

**C++ Primer中文版(第4版).pdf** (ed2k://|file|C%2B%2B%20Primer%E4%B8%AD%E6%96%87%E7%89%88%28%E7%AC%AC4%E7%89%88%29.pdf|2980574|01816022b8240f8eefedfe0f0fee890f|h=owrgimq3bxc32quxhqlcbo7ayhbehtl4|/)

**C Programming for Arduino.pdf** (ed2k://|file|C%20Programming%20for%20Arduino.pdf|9990425|b50fc2687ed1dcf3da2ec655e9e88474|h=njhdavlrqnwzzvdyz4ti4ovt4vqv7qpf|/)

**Microsoft Silverlight Edition_ Programming Windows Phone 7.pdf** (ed2k://|file|Microsoft%20Silverlight%20Edition_%20Programming%20Windows%20Phone%207.pdf|10708372|131a185f3fd1163d132816ed1e4c8363|h=hzhyomwyyvuipemwtboelp4dc5fboy65|/)

**DWDM Network Designs and Engineering Solutions.pdf** (ed2k://|file|DWDM%20Network%20Designs%20and%20Engineering%20Solutions.pdf|8926786|e31afe8ab2201b7003d17ee7f1b3be7e|h=oijgzb4govy5hnt5dpsub36s74o7bga2|/)

**Network Security Principles and Practices.chm** (ed2k://|file|Network%20Security%20Principles%20and%20Practices.chm|5083273|4d666cf18d9b33cf595babfba44ca9af|h=zicefbhf3kz77e7p4og5u4w2aqxf7e5d|/)

**Top-Down Network Design Second Edition.chm** (ed2k://|file|Top-Down%20Network%20Design%20Second%20Edition.chm|3000181|29fbdd58df426c1f479f0b61faaa9ba4|h=skf7uc736kobjoqwxjquyyz2fbh3xzh5|/)

**Guide to Computer Network Security.pdf** (ed2k://|file|Guide%20to%20Computer%20Network%20Security.pdf|12602154|a0c9b35221a6fa712ff43e6d7d9603ba|h=yxigncfu54ec5biov2khrno7soskueqv|/)

**SQL in a Nutshell, 2nd Edition.chm** (ed2k://|file|SQL%20in%20a%20Nutshell%2C%202nd%20Edition.chm|1140008|d3fb517e5bb5fb0cc2b07962b0288a40|h=ookcpfl5ao6q3mt5aftpansbfumoum4o|/)

**Developing Microsoft SharePoint Applications Using Windows Azure.pdf** (ed2k://|file|Developing%20Microsoft%20SharePoint%20Applications%20Using%20Windows%20Azure.pdf|31393950|cfe69a202bb1e41a1afb705b49de022d|h=r6beaozcztendn2xqapjdcogofwkmfxp|/)

**A Beginner’s Guide to R.pdf** (ed2k://|file|A%20Beginner%E2%80%99s%20Guide%20to%20R.pdf|7558890|23d250209b91bba71977bb2d8ee7f54c|h=nkxwa3jr7fgw7ytwa7rtql5pkftbigjd|/)

**Financial Analysis tools and techniques_ A guide for managers.pdf** (ed2k://|file|Financial%20Analysis%20tools%20and%20techniques_%20A%20guide%20for%20managers.pdf|3526681|a670914cd5b642fbff24dbee11ce4d56|h=fbrpxlbbtq6lku3xxu44oxpepxbbqisi|/)

**The CERT Oracle Secure Coding Standard for Java.pdf** (ed2k://|file|The%20CERT%20Oracle%20Secure%20Coding%20Standard%20for%20Java.pdf|3945848|2bceac57aeeec69c12d6653f281b0a8a|h=2sec3ddhs6l4vogfpgzksuotebm7pxmw|/)

**PHP & MySQL_ Novice to Ninja, 5th Edition.pdf** (ed2k://|file|PHP%20%26%20MySQL_%20Novice%20to%20Ninja%2C%205th%20Edition.pdf|11430634|814527a7bdbd51d2bda2962c5907a4eb|h=6zotomqk5etm5p3ka54v352nmjbo23rz|/)

**Android – A Programmers Guide.pdf** (ed2k://|file|Android%20%E2%80%93%20A%20Programmers%20Guide.pdf|7583528|2d1500f8bb4a22278a5393143f756a4b|h=oqn2vxiyfvxgzdghk7cchlkvw7fauobr|/)

**Running Linux, 5th Edition.pdf** (ed2k://|file|Running%20Linux%2C%205th%20Edition.pdf|15265524|e3dc79e5f05e17a5c4727610f1ed7b11|h=uj65hhojxxedp7idgurn6aes5nfhbmcw|/)

**Cloud Architecture Patterns.pdf** (ed2k://|file|Cloud%20Architecture%20Patterns.pdf|8674363|aa8c20953f6512f4f6d38c4847ed4858|h=w6pqs4qok5xenvnmqqi56lo5polizbz5|/)

**深入理解Linux虚拟内存管理.pdf** (ed2k://|file|%E6%B7%B1%E5%85%A5%E7%90%86%E8%A7%A3Linux%E8%99%9A%E6%8B%9F%E5%86%85%E5%AD%98%E7%AE%A1%E7%90%86.pdf|46808838|8960e4971927fb44ee539e087706dc83|h=sfy5rtfj4cwq4sxu653wb7fm2vric6nr|/)

**Red Hat Enterprise Linux 5 Administration Unleashed.pdf** (ed2k://|file|Red%20Hat%20Enterprise%20Linux%205%20Administration%20Unleashed.pdf|7654816|1897924460bbdbff1976c476a2495271|h=quxtyrlldhljcwgd3xheahkqlyfcvg5d|/)

**Fedora 6 and Red Hat Enterprise Linux Bible.chm** (ed2k://|file|Fedora%206%20and%20Red%20Hat%20Enterprise%20Linux%20Bible.chm|10897336|864d278caabc26c679a64a1283f2d7c3|h=4uxmognzrsrh572re2pps2zlcv4qq6iu|/)

**C#技术内幕.pdf** (ed2k://|file|C%23%E6%8A%80%E6%9C%AF%E5%86%85%E5%B9%95.pdf|6735664|16fc4d0000e26487c1d9630aadd9ae7c|h=netpooynzii5xx47yh4igzwwcgbmcsdr|/)

**Data Mining_ Practical Machine Learning Tools and Techniques, Third Edition.pdf** (ed2k://|file|Data%20Mining_%20Practical%20Machine%20Learning%20Tools%20and%20Techniques%2C%20Third%20Edition.pdf|7276980|0fcf136e084dd612acac3fda040a2d10|h=yti7gf5vxsn7fxru6d3doahfqxyn6ug2|/)

**The Definitive Guide to Linux Network Programming.pdf** (ed2k://|file|The%20Definitive%20Guide%20to%20Linux%20Network%20Programming.pdf|3783273|5033a7a23bfdfcee4bdf5c25c5976fd4|h=i5kqdnlrft2xhtdrhavzlakedp76klfw|/)

**Handbook of Security and Networks.pdf** (ed2k://|file|Handbook%20of%20Security%20and%20Networks.pdf|9222253|7632d190f2054c3c233cad59db48ab9f|h=ja5dmvm2uuyfusjpswoxrlqnafbabvza|/)

**ASP.NET 4 Unleashed.rar** (ed2k://|file|ASP.NET%204%20Unleashed.rar|30178847|685a47b46dc436dbcbf2102b0ed3f2e8|h=56vucjusywprnjmdtmjlbmdgezklrgki|/)

**Linux on HP Integrity Servers_ A System Administrator’s Guide.chm** (ed2k://|file|Linux%20on%20HP%20Integrity%20Servers_%20A%20System%20Administrator%E2%80%99s%20Guide.chm|6682998|895a2e5cac3acb0ea43170a9448a0975|h=xlkizajgwjdznmsuynryamt2vmh4nbwm|/)

**Working with Unix Processes.pdf** (ed2k://|file|Working%20with%20Unix%20Processes.pdf|2200013|42cd42e21c4f8d5b4a2b1e89f0e94457|h=ahkqomynvkjbna7cabfufhao3vlrkhst|/)

**UDK iOS Game Development_ Beginners Guide.pdf** (ed2k://|file|UDK%20iOS%20Game%20Development_%20Beginners%20Guide.pdf|14120506|75c20a63aafa6ffbe18bfed6fb6bfa85|h=244hpyxduyqjf32bmwq32rtvttpbcmta|/)

**JavaScript_ The Good Parts.chm** (ed2k://|file|JavaScript_%20The%20Good%20Parts.chm|1704386|80dcf62e5226d4d9bc7a421b7af5ff30|h=cregnfrautv6jb5snb6tvkeauxt2uodz|/)

**The Django Book 2.0 中文版.chm** (ed2k://|file|The%20Django%20Book%202.0%20%E4%B8%AD%E6%96%87%E7%89%88.chm|1219657|03abddd7885f31c351b7e626d9c613dd|h=ax4kiehq77wlgcc6iwke77tgiug2urnb|/)

**Accelerated Silverlight 2.rar** (ed2k://|file|Accelerated%20Silverlight%202.rar|4858128|a998ab26aeee4c64d5da416c10a21205|h=eimfuqkwnvxudbmoakx6kp3amvbwf3uw|/)

**Mastering.ElasticSearch for java.pdf** (ed2k://|file|Mastering.ElasticSearch%20for%20java.pdf|2850206|9f48e09e8e4e14e786b05c990024cd6a|h=wgrgyuwdwzhzfjazirllru6sbxbcksui|/)

**数据重现：文件系统原理精解与数据恢复最佳实践.pdf** (ed2k://|file|%E6%95%B0%E6%8D%AE%E9%87%8D%E7%8E%B0%EF%BC%9A%E6%96%87%E4%BB%B6%E7%B3%BB%E7%BB%9F%E5%8E%9F%E7%90%86%E7%B2%BE%E8%A7%A3%E4%B8%8E%E6%95%B0%E6%8D%AE%E6%81%A2%E5%A4%8D%E6%9C%80%E4%BD%B3%E5%AE%9E%E8%B7%B5.pdf|45660017|77b97796acd30be04d07c2351ace9525|h=glabzl3dlg5ycmzsteklygh72lvrxsxs|/)

**Absolute Java 5_e.pdf** (ed2k://|file|Absolute%20Java%205_e.pdf|10475838|92bc596c5489c04da23f8c1c606f17d9|h=ruujl7m7ll5lkjnpqw3itzt5re3dczro|/)

**Pro DNS and BIND.pdf** (ed2k://|file|Pro%20DNS%20and%20BIND.pdf|3291293|3c6400084ab114f51d902928f0037d5d|h=fre3cydtbiihbxkemdxoaxfvvpj5ucop|/)

**虚拟智慧_VMware vSphere运维实录.pdf** (ed2k://|file|%E8%99%9A%E6%8B%9F%E6%99%BA%E6%85%A7_VMware%20vSphere%E8%BF%90%E7%BB%B4%E5%AE%9E%E5%BD%95.pdf|48244141|80e0a00c151f6a37aa822e8eb4e55f82|h=ajpxep4kbg3p33w2gz4ovxzdwjullrm4|/)

**VMware vSphere Design.pdf** (ed2k://|file|VMware%20vSphere%20Design.pdf|8946164|6d52d9d89d689c6bc18cbc2b75b3085b|h=fcyiq53i2uszjmqdibrlaazwikl7f2xb|/)

**VMware Cookbook, 2nd Edition.pdf** (ed2k://|file|VMware%20Cookbook%2C%202nd%20Edition.pdf|13132206|d50db60164c82c6b8040086d583b810f|h=gem7tgplhuxgg4mivbnqhsskygopyzvt|/)

**Managing and Optimizing VMware vSphere Deployments.pdf** (ed2k://|file|Managing%20and%20Optimizing%20VMware%20vSphere%20Deployments.pdf|4795899|cb669b7d5bd81240d5699c38d38cc499|h=767xuexq5fgwzbaw3rbitdzx6rwlgdf5|/)

**VMware vSphere 5 Clustering Technical Deepdive.pdf** (ed2k://|file|VMware%20vSphere%205%20Clustering%20Technical%20Deepdive.pdf|14337099|b51aaeeffaf420a85c34110166b50be6|h=hhhi3wxsy2p662lotlbpe2a6uixdxhch|/)

**VMware vSphere 5.1 Clustering Deepdive.pdf** (ed2k://|file|VMware%20vSphere%205.1%20Clustering%20Deepdive.pdf|12309468|eb3ca8cace7eebaf987c1040c1140b38|h=a6hhb52s5f4kq7qxim7qktxm2n27jht2|/)

**VCP5 VMware Certified Professional on vSphere 5 Study Guide Exam VCP-510.pdf** (ed2k://|file|VCP5%20VMware%20Certified%20Professional%20on%20vSphere%205%20Study%20Guide%20Exam%20VCP-510.pdf|18617345|87b3b824ce184f247b1ee7d2726df38a|h=qkptgmej6z3vn3tttsmmxktizua26d5n|/)

**Microsoft IIS 7 Implementation and Administration.pdf** (ed2k://|file|Microsoft%20IIS%207%20Implementation%20and%20Administration.pdf|16586885|cabd49d88816221f2bcf2ad506b241d5|h=35xsptskxj3hr5prf2csyny3qqksjou3|/)

**Professional IIS 7.pdf** (ed2k://|file|Professional%20IIS%207.pdf|16983044|aa0cc4e0b7c3f185c57f3bfb6274042d|h=nqbz4qrabk6xnuxm7hgebsowssbocyc2|/)

**Professional IIS 7 and ASP.NET Integrated Programming.pdf** (ed2k://|file|Professional%20IIS%207%20and%20ASP.NET%20Integrated%20Programming.pdf|7145332|163845e17c107de40af166d4b200d072|h=yil76e6zjpprperigd4s5hunbqemhtrk|/)

**Internet Information Services (IIS) 7.0 Resource Kit Book.pdf** (ed2k://|file|Internet%20Information%20Services%20%28IIS%29%207.0%20Resource%20Kit%20Book.pdf|16710028|96ac9f48bac6a8adcab531c704b22bec|h=5bkvsaic2wycq5suu2wvgel6w62tpjjx|/)

**Social Network Data Analytics.pdf** (ed2k://|file|Social%20Network%20Data%20Analytics.pdf|4765654|7054d3c4e3204744ec56aa18ab1cf9d8|h=drsvp3iebwrx75ffklpdlj3sdtuqqiub|/)

**CSS Pocket Reference, Fourth Edition.pdf** (ed2k://|file|CSS%20Pocket%20Reference%2C%20Fourth%20Edition.pdf|4303244|0e4e6b215ec10258709799fd1d4d1b27|h=aown6xmgwypc2xvoal5rm72dtinpcr2r|/)

**数据结构（C#语言版）.pdf** (ed2k://|file|%E6%95%B0%E6%8D%AE%E7%BB%93%E6%9E%84%EF%BC%88C%23%E8%AF%AD%E8%A8%80%E7%89%88%EF%BC%89.pdf|1740085|a6bb308d4f4245eec289b834cec9fa60|h=cwrzyo7ukt5vommery4w6anjru6olyjl|/)

**The Jargon File, Version 4.2.2, 20 Aug 2000.pdf** (ed2k://|file|The%20Jargon%20File%2C%20Version%204.2.2%2C%2020%20Aug%202000.pdf|1415406|776add22f74611fc3586962554bd073c|h=rrz453piznrbtvg2lmg5z2bzqmlqh3zg|/)

**IP for 3G_ Networking Technologies for Mobile Communications.pdf** (ed2k://|file|IP%20for%203G_%20Networking%20Technologies%20for%20Mobile%20Communications.pdf|3015138|783b6114dd03c67d5a365664eaf7022a|h=xmnwrzvdmwlayrkriqgakgal55sarvwo|/)

**Professional Microsoft IIS 8.pdf** (ed2k://|file|Professional%20Microsoft%20IIS%208.pdf|21910978|08fe238461a2f8224ddaa32b204d51b6|h=5i7r7tawim4s7ibvbeiypbbvxdqnrwo5|/)

**On Lisp 中文版.pdf** (ed2k://|file|On%20Lisp%20%E4%B8%AD%E6%96%87%E7%89%88.pdf|2423674|cebdbdd78be076267cb29d742494ff65|h=n4hv4xktf4tcbvcjrahkhinju4zfiu24|/)

**Storage Implementation in vSphere 5.0.pdf** (ed2k://|file|Storage%20Implementation%20in%20vSphere%205.0.pdf|52160217|cd157458d6d84ee24fba95bd99d8a711|h=wlxcm7xm6o6zpztzrtmctwq6tqf4fuoi|/)

**可计算性与数理逻辑（第四版）.pdf** (ed2k://|file|%E5%8F%AF%E8%AE%A1%E7%AE%97%E6%80%A7%E4%B8%8E%E6%95%B0%E7%90%86%E9%80%BB%E8%BE%91%EF%BC%88%E7%AC%AC%E5%9B%9B%E7%89%88%EF%BC%89.pdf|8589757|0babc30f9fb14bae5ebaf1d885e0997c|h=th54625mhcabf4lel4kfrmzxbcdxplen|/)

**Electronics For Dummies.pdf** (ed2k://|file|Electronics%20For%20Dummies.pdf|20911647|6646a1473f1d935cd42aa21360027349|h=fgbawhxid22gf4vwyuta7eafn4bmes52|/)

**C++标准库_自学教程与参考手册(第2版)(英文版).pdf** (ed2k://|file|C%2B%2B%E6%A0%87%E5%87%86%E5%BA%93_%E8%87%AA%E5%AD%A6%E6%95%99%E7%A8%8B%E4%B8%8E%E5%8F%82%E8%80%83%E6%89%8B%E5%86%8C%28%E7%AC%AC2%E7%89%88%29%28%E8%8B%B1%E6%96%87%E7%89%88%29.pdf|14641522|3624e93a73ff5a002a69b5f340a2c339|h=cjdfjwd6e4rinppeupusynaamjhtcruw|/)

**Kohana 3.0 Beginner’s Guide.pdf** (ed2k://|file|Kohana%203.0%20Beginner%E2%80%99s%20Guide.pdf|5139628|9fd8369b0d2bea987587f9b721d143c0|h=uimyvvx3is3m4d6j7kt6fqnbxukotxys|/)

**The Elements of Computing Systems.pdf** (ed2k://|file|The%20Elements%20of%20Computing%20Systems.pdf|3664583|571ec81203b2a7203ecc8f26c103ea82|h=zi6bcmtjhsxpacsggymdzac7wwogv7ru|/)

**精通Dojo.pdf** (ed2k://|file|%E7%B2%BE%E9%80%9ADojo.pdf|31117098|cbc11b77f0acac9aa86525952e3c684a|h=b6eoejnn2hr53dwpoyumhv6js4rwgih2|/)

**Data Mining in Grid Computing Environments.pdf** (ed2k://|file|Data%20Mining%20in%20Grid%20Computing%20Environments.pdf|5158955|c7ca1228743da4ff1a501c9fc3dd9aff|h=tdffhtz7srvkun2tnqgcnagifncjgibs|/)

**Programming Windows 8 Apps with HTML, CSS and JavaScript, 2Ed.pdf** (ed2k://|file|Programming%20Windows%208%20Apps%20with%20HTML%2C%20CSS%20and%20JavaScript%2C%202Ed.pdf|12034552|ac7571711bcc609a101cd9d64e18bce9|h=kiunqvgvofjfjv4vv4fpcyleb7yu3ivk|/)

**Learn HTML5 and JavaScript for Android.pdf** (ed2k://|file|Learn%20HTML5%20and%20JavaScript%20for%20Android.pdf|6614021|4c06aae807d98bc09866d2f315fac74d|h=u2j5jby7cnycbhmskqahlhkqzxj26s6f|/)

**Learning Web Design_ A Beginner’s Guide to HTML, CSS, JavaScript, and Web Graphics, 4th Edition.pdf** (ed2k://|file|Learning%20Web%20Design_%20A%20Beginner%E2%80%99s%20Guide%20to%20HTML%2C%20CSS%2C%20JavaScript%2C%20and%20Web%20Graphics%2C%204th%20Edition.pdf|25160467|1f2ea129c8f6e0b2ae7b87dfade7f3e5|h=cuwx72ffiphqvwgd4oxgbfi4pvcpqqck|/)

**HTML5 and JavaScript Web Apps.pdf** (ed2k://|file|HTML5%20and%20JavaScript%20Web%20Apps.pdf|4959246|cac5b2a44fde6ef08c161b1101ba1a76|h=z4nneiyg75hjwqvazceuwqmleyqrw6kr|/)

**Adobe Photoshop CS6 Classroom in a Book.pdf** (ed2k://|file|Adobe%20Photoshop%20CS6%20Classroom%20in%20a%20Book.pdf|16805482|7fae5ae7e88e3569bfa9d924c18e72c3|h=j4ss4wyrlo4pp5dcskjg3qazjt4ew4sl|/)

**Visual QuickStart Guide Photoshop CS6.pdf** (ed2k://|file|Visual%20QuickStart%20Guide%20Photoshop%20CS6.pdf|35711799|b4df5fe51d7a6cbb3d9c0f3dbcf1bb38|h=le3y3q2aeirfhg62zzezfsphi2jb2vy6|/)

**Fearless Flash_ Use Adobe InDesign CS5 and the Tools You Already Know to Create Engaging Web Documents.pdf** (ed2k://|file|Fearless%20Flash_%20Use%20Adobe%20InDesign%20CS5%20and%20the%20Tools%20You%20Already%20Know%20to%20Create%20Engaging%20Web%20Documents.pdf|17306790|c237318ec287ca2392aa3dcb6f89c369|h=i7cz2ueklimx6yevkxdpmw3wctg6ohtg|/)

**Adobe Creative Suite 4 Design Premium All-in-One For Dummies.pdf** (ed2k://|file|Adobe%20Creative%20Suite%204%20Design%20Premium%20All-in-One%20For%20Dummies.pdf|22464476|7bdeeedfa97ab7243fc7c805a6f30089|h=bvbimiegoo7r67jddiv2fpcq7xhmzfz3|/)

**Adobe Creative Suite 5 Web Premium How-Tos_ 100 Essential Techniques.pdf** (ed2k://|file|Adobe%20Creative%20Suite%205%20Web%20Premium%20How-Tos_%20100%20Essential%20Techniques.pdf|7370595|1608df434e178e4968401b87461a1649|h=7oodzzr6rstszzmpn7573rgu2bhrnm7m|/)

**Adobe Creative Suite 5 Design Premium All-in-One For Dummies.pdf** (ed2k://|file|Adobe%20Creative%20Suite%205%20Design%20Premium%20All-in-One%20For%20Dummies.pdf|22862816|c7e067392bac29f1095112d3717837d0|h=uxquf7fuv2ggcouowwafcbotct3fgxs5|/)

**Website Design and Development_ 100 Questions to Ask Before Building a Website.pdf** (ed2k://|file|Website%20Design%20and%20Development_%20100%20Questions%20to%20Ask%20Before%20Building%20a%20Website.pdf|14642814|2515ea3326110c34b79549a3c12cf49d|h=tn57s2qlcyfuzx7mitwtzaftiyn6kaib|/)

**Data Structure And Algorithms In C++, 2nd ed.zip** (ed2k://|file|Data%20Structure%20And%20Algorithms%20In%20C%2B%2B%2C%202nd%20ed.zip|4075892|951757de41ab18c8da73850daa22b8b0|h=d5523lmio4s5mru2dw66ul3kwa7wejy4|/)

**数据结构与算法分析–C++描述（第3版）.pdf** (ed2k://|file|%E6%95%B0%E6%8D%AE%E7%BB%93%E6%9E%84%E4%B8%8E%E7%AE%97%E6%B3%95%E5%88%86%E6%9E%90%E2%80%93C%2B%2B%E6%8F%8F%E8%BF%B0%EF%BC%88%E7%AC%AC3%E7%89%88%EF%BC%89.pdf|25670271|834f603da6130a2ded2d16e966bee186|h=boxrcm5wyuzeltkwhari23rnw46aj6c5|/)

**Building Software for Simulation_ Theory and Algorithms, with Applications in C++.pdf** (ed2k://|file|Building%20Software%20for%20Simulation_%20Theory%20and%20Algorithms%2C%20with%20Applications%20in%20C%2B%2B.pdf|6587336|5a5028ba050b00e33619504a32c171af|h=uygz3wtkyjfbgofgtnioxtjdrpcml63g|/)

**Data Structures and Algorithms in C++.pdf** (ed2k://|file|Data%20Structures%20and%20Algorithms%20in%20C%2B%2B.pdf|17677509|d7b96f816b8b92fff1e9622ded9aca72|h=icu4rsmeb4ynts6hk6sp6yanmxsack5g|/)


