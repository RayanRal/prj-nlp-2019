Source: https://github.com/ggozad/mnemonic.js

Size: 1626

Sort: alphabetic

mnemonic.js uses a relatively small (1626 to be exact) set of English words that are chosen from the list of frequently used words in contemporary English poetry and are (hopefully) memorable.

The idea behind mnemonic.js was blatantly stolen from the excellent electrum bitcoin client.

