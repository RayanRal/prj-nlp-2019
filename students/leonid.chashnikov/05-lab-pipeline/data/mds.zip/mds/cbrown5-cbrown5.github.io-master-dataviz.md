---
layout: default
title: Dataviz 2018
sitemap:
    priority: 0.7
    changefreq: 'monthly'
    lastmod: 2018-06-29
---

# Take the dataviz quiz

[Click here to redirect to the quiz on Google forms](https://docs.google.com/forms/d/e/1FAIpQLSd5v5d15q8KO7VyfjRRrfGV1NadKVyLpyAdzqu2Fvreq40UXg/viewform)

If you are **interested in learning more about R** then take one of our courses. The next set of courses (as of writing) is at [University of Queensland on 5th February 2019](https://smp.uq.edu.au/event/session/5650). These cover topics from an introduction for absolute beginners to advanced R programming.  

You can read more about the talk in [these notes, which include an R code 'how to' for the figures, which go with my talk](/rstats/2018/07/04/dataviz2018_notes.html). 

