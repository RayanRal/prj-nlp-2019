# poetry book
this is my place to post my poetry

I know I could make a blog but I like the idea of having a git history on my work, that way I wont be afraid to refactor (or "edit" as the writers call it) my poems. If I prefer the original version or find that I want to make changes, I can do so while also preserving a history of desicions I made.

Anyone is welcome to comment, critisize, fork, repost, and clone my work. I'm not protective of it. *My signed git history will prove you wrong if you claim it as yours anyways.*

PRs welcome! If you want to add a poem make sure you understand the MIT license!
