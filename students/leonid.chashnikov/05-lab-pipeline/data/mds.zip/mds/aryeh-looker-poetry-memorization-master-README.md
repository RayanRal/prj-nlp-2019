# poetry

Helps with memorizing things like poetry

## Usage

lein run <filename>

## Examples

	aryeh [2017-07-30 16:00:18]:~/Development/poetry$ lein run ~/Development/burnt-norton.txt
	Opening: /Users/user/Development/burnt-norton.txt
	hhh
	BURNT NORTON
	BURNT NORTON
	
	(No. 1 of 'Four Quartets')
	(No. 1 of 'Four Quartets')
	
	
	Time present and time past
	Time present and time past 
	Are both contained in time present
	Are both perhaps present in time future,
	Are both perhaps present in time future,
	
	And time future contained in time past.
	And time future contained in time past.
	
	If all time is eternally present
	If all time is eternally present
	
	All time is unredeemable.
	All time is unredeemable.
	

