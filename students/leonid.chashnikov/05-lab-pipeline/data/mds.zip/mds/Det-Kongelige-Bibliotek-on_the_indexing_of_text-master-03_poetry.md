[introduction](01_introduction.md) | [on the theory of text](02_theory_of_text.md) | [text genres](03_letter.md) | [record vs text](04_records_vs_text.md) | [filtering vs searching](05_filtering_vs_searching.md) | [discussion](06_discussion.md) | [references](07_references.md)

[letter](03_letter.md) | [play](03_play.md) | [poetry](03_poetry.md) | [prose](03_prose.md)

# 2c. Text genres: Markup of a piece of poetry

![Piece of poetry with metadata](https://rawgit.com/Det-Kongelige-Bibliotek/on_the_indexing_of_text/master/poetry.svg) Figure 4. 

