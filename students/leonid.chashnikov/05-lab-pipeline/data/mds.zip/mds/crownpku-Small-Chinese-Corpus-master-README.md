
# 中文语料小数据：Some useful Chinese corpus datasets

* 中国省市经纬度坐标：city_location/

* 中国省市邮政编码大全：postal_provinces/

* 全国区划和城乡划分代码(2015)：china_geo_code/

* 成语大全：chengyu/

* 中文人名大全及金庸小说、三国演义及红楼梦人物姓名：chi_names/

* 中文命名实体识别数据sample：NER_chi/

* 中文关系识别数据sample：relation_multiple_chi/

* 中文阅读理解数据sample：reading_comprehension_chi/

* 中文图文问答数据（基于MSCOCO）：Chinese_Visual_QA_pairs/


