## 皮皮书屋电驴下载资源 

**Programming Embedded Systems with C and GNU Development Tools, 2nd Edition.pdf** (ed2k://|file|Programming%20Embedded%20Systems%20with%20C%20and%20GNU%20Development%20Tools%2C%202nd%20Edition.pdf|4392937|1e5bff70bbf4d4a2b3cfa1f8e2b7fc1c|h=fxperzb7guvk3ixzahjz4aws35cuppew|/)

**Greasemonkey Hacks.chm** (ed2k://|file|Greasemonkey%20Hacks.chm|8169363|44b4b6082617ba2ce6fcce52b0643577|h=yvylae3svnd4jnhelpxz3mceh6fn6fsp|/)

**Introduction to Data Mining for the Life Sciences.pdf** (ed2k://|file|Introduction%20to%20Data%20Mining%20for%20the%20Life%20Sciences.pdf|21543544|5ecf0138e9c6780ca28aaa46cb699b32|h=b6vwqrbcs2vvaozxwjalwidaxipgdohd|/)

**Testable JavaScript.pdf** (ed2k://|file|Testable%20JavaScript.pdf|19105178|1539dc70658797f2bc554d011fff26b7|h=waeezopofz2o44wpx46vgmy4n4yus6by|/)

**Compiler Design_ Syntactic and Semantic Analysis.pdf** (ed2k://|file|Compiler%20Design_%20Syntactic%20and%20Semantic%20Analysis.pdf|3316088|8d872f45978df5c554b6fa6643f2f12a|h=efxu4xvqyxqqyydbxwwzzkdgjamtk6xz|/)

**App Inventor_ Create Your Own Android Apps.pdf** (ed2k://|file|App%20Inventor_%20Create%20Your%20Own%20Android%20Apps.pdf|29295557|3132d578dab4b824009668b135213d23|h=uxio6tbkl3xhgy6xbeimqxxrit3n3r2f|/)

**新手学黑客攻防.pdf** (ed2k://|file|%E6%96%B0%E6%89%8B%E5%AD%A6%E9%BB%91%E5%AE%A2%E6%94%BB%E9%98%B2.pdf|29673441|5fb922e5b385f1933a6515656065f29e|h=pmmrwhlbk5jllm5b4itmu4otnjv4zkvm|/)

**On Lisp.pdf** (ed2k://|file|On%20Lisp.pdf|1030575|69b06c8bd3156fd54c1b1988c71cadeb|h=ctbisgkpt5ypsr4fdtfpzmu2cbouw34r|/)

**C++ Primer, Fifth Edition.pdf** (ed2k://|file|C%2B%2B%20Primer%2C%20Fifth%20Edition.pdf|19009993|f03c055d7a1f8f114304f3d76213aeb2|h=5di4lorhwr2ytkj6qndsgaz2k6rh5rct|/)

**JavaScript Programming_ Pushing the Limits.pdf** (ed2k://|file|JavaScript%20Programming_%20Pushing%20the%20Limits.pdf|31843999|ea2482aa96a87553ba6643ad1e120c97|h=e24ic7gtsvx4vn3bohdyindh4qgybdnj|/)

**50 Tips and Tricks for MongoDB Developers.pdf** (ed2k://|file|50%20Tips%20and%20Tricks%20for%20MongoDB%20Developers.pdf|5590568|ee36f29488553e3a9ec11d002e573eca|h=5yfaerus5dunwlalagq2rt2zfbgfaivf|/)

**Discrete Mathematics and its Applications.pdf** (ed2k://|file|Discrete%20Mathematics%20and%20its%20Applications.pdf|36025151|fd618aa83571029c4a6c526f5951fc2d|h=5asmtvhz2ugy2z4cn3ksmgwsuelnns7g|/)

**SQL_ Visual QuickStart Guide (3rd Edition).pdf** (ed2k://|file|SQL_%20Visual%20QuickStart%20Guide%20%283rd%20Edition%29.pdf|4676798|9382ec66d1601d4315bec7e373d9d5ef|h=stetyr4zitk7thfzdnvjlqlqtmxagj5l|/)

**Programming Collective Intelligence.pdf** (ed2k://|file|Programming%20Collective%20Intelligence.pdf|29253251|b8c3b4d08e37ba0b7d724e039fb82a3a|h=xvbmvxkaxztg6asuu72gifyonoucecrl|/)

**Website Owner’s Manual.pdf** (ed2k://|file|Website%20Owner%E2%80%99s%20Manual.pdf|16583685|151fcbfb08c85ac876b29fe7158597d7|h=gkiizloym7onrkn3gmlabjvz5nytorby|/)

**Pro Perl.pdf** (ed2k://|file|Pro%20Perl.pdf|4332981|38551e55d710561b25db2a1bc96c933d|h=3wpw2fc3tsbfqyl6pdbknx7e5zrzwqtc|/)

**Application Testing with Capybara.pdf** (ed2k://|file|Application%20Testing%20with%20Capybara.pdf|1757929|136389901dd68d21b5128f972532c0a3|h=se2bjf7lijcazv3j3l63y6vzp4vge3tl|/)

**LoadRunner性能测试完全讲义.pdf** (ed2k://|file|LoadRunner%E6%80%A7%E8%83%BD%E6%B5%8B%E8%AF%95%E5%AE%8C%E5%85%A8%E8%AE%B2%E4%B9%89.pdf|26022520|a9edcee9ca0f545eeed3bc2923ad25b0|h=xtqyzetwevz6k3tjh4pob5z5pzqyarku|/)

**c++ unleashed.pdf** (ed2k://|file|c%2B%2B%20unleashed.pdf|4208867|72d91f84989c93f327d6d378f0260531|h=4vbukwrxujhawv73m23px7uep6nnx6vo|/)

**Mastering HTML5 Forms.pdf** (ed2k://|file|Mastering%20HTML5%20Forms.pdf|1378067|3c9624619a3ac29226a5871283d41524|h=oupmrfqois45dcpunzecnqs37szyoh5z|/)

**Exceptional C++.zip** (ed2k://|file|Exceptional%20C%2B%2B.zip|1974240|275d5134524dda1fdfef71fdcf7277d8|h=qnf4fts3n4eb5tonatntcb6sjcsmyu5x|/)

**CSS The Missing Manual 2nd Edition.pdf** (ed2k://|file|CSS%20The%20Missing%20Manual%202nd%20Edition.pdf|19435943|f18011ee32afdb7425b685363c9b938e|h=kjrwstes3bvh4ms2tavsuqnxb6ai43b2|/)

**A First Look at ASP.NET v. 2.0.chm** (ed2k://|file|A%20First%20Look%20at%20ASP.NET%20v.%202.0.chm|4010850|a55bdf08dc98e6dc6c3f1342aba0467e|h=bdydhk6rwmcdukvkf7pifiajtsbuuq2d|/)

**OpenStack实战指导手册.pdf** (ed2k://|file|OpenStack%E5%AE%9E%E6%88%98%E6%8C%87%E5%AF%BC%E6%89%8B%E5%86%8C.pdf|471248|d8314686cfd07bd924bef15003f385ec|h=cqio4oratvzm7hqck6btzovj7tkio4wy|/)

**计算机组成原理(第2版).pdf** (ed2k://|file|%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BB%84%E6%88%90%E5%8E%9F%E7%90%86%28%E7%AC%AC2%E7%89%88%29.pdf|15834200|897e22d6513eb02c83c9fc3e0afde822|h=syeuc3lq3xefwrncokmoqvw24iy5mv4c|/)

**Pro Android.pdf** (ed2k://|file|Pro%20Android.pdf|5920666|a995636b552942fdbe5b5f7a6d2005ab|h=ndseeqgg64by3mrbqysudqdzx4llfta5|/)

**ActionScript 3.0 Bible.pdf** (ed2k://|file|ActionScript%203.0%20Bible.pdf|19384857|31fecf471f77366650a9ebb277b9c3be|h=tdayivqqxppcouwz6fvq7bp6umqsrarx|/)

**BlackBerry For Dummies, 4th Edition.pdf** (ed2k://|file|BlackBerry%20For%20Dummies%2C%204th%20Edition.pdf|10651204|f0d9c966256a641df28c73e6c5a46a20|h=e4aurn6c5cpllecg7papujikafqsfh6z|/)

**Mastering Microsoft Windows Small Business Server 2008.pdf** (ed2k://|file|Mastering%20Microsoft%20Windows%20Small%20Business%20Server%202008.pdf|8365438|ecf35e4742d9605fe7b674a22fb0a0ee|h=ymsihtrc7atgbwadgloeks4z4rh5lkxw|/)

**Professional Node.js_ Building Javascript Based Scalable Software.pdf** (ed2k://|file|Professional%20Node.js_%20Building%20Javascript%20Based%20Scalable%20Software.pdf|12648882|878630daa578f05286de4dadacbfdbd8|h=3ewcz2mp2oy2q2gyzllxh55fif3fvs4b|/)

**TCP_IP路由技术(第2卷).pdf** (ed2k://|file|TCP_IP%E8%B7%AF%E7%94%B1%E6%8A%80%E6%9C%AF%28%E7%AC%AC2%E5%8D%B7%29.pdf|21901436|38f766b4f9786bc7d7dafe9481cd5612|h=lragib4qgqa2sp766kps6cstap2ltc5s|/)

**计算机组成结构化方法（第5版）.pdf** (ed2k://|file|%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%BB%84%E6%88%90%E7%BB%93%E6%9E%84%E5%8C%96%E6%96%B9%E6%B3%95%EF%BC%88%E7%AC%AC5%E7%89%88%EF%BC%89.pdf|31363887|42e0dae61c60f7b8a7aa6d7dee6f09a2|h=t6kg2l4c7csezim5imxrypp7qq377cdy|/)

**Optimizing Windows 7 Pocket Consultant.pdf** (ed2k://|file|Optimizing%20Windows%207%20Pocket%20Consultant.pdf|8775422|b571384e52e92bac97b91f1fb8e49b98|h=ql6owc6ij4ir66iaovfcle2b2uclt4sv|/)

**Teach Yourself VISUALLY Access 2010.pdf** (ed2k://|file|Teach%20Yourself%20VISUALLY%20Access%202010.pdf|48529905|bd6da48b3a48113dda5313c923d5257f|h=izg6fx2lq7b6hikp76xsfceriged7zqn|/)

**The Definitive Guide to iReport.pdf** (ed2k://|file|The%20Definitive%20Guide%20to%20iReport.pdf|12697961|c84750e78ae9247e7cb10d51f376fee1|h=yjisrjcb4ew2any7hvzdvyeggy3tdp4l|/)

**Design Pattern Mini Book.pdf** (ed2k://|file|Design%20Pattern%20Mini%20Book.pdf|2223123|9e0665741e5af37cb571a52ee5e9d1ed|h=m4hqhylh74ttvjz5peyhjktzqnxz7zhy|/)

**Pro SQL Server 2008 Service Broker.pdf** (ed2k://|file|Pro%20SQL%20Server%202008%20Service%20Broker.pdf|6815140|4ba65408da9264c5bf3defac123e4a52|h=zrcbybrf5r53zj5j2kqbeur5oa2dfjsb|/)

**Enterprise AJAX_ Strategies for Building High Performance Web Applications.pdf** (ed2k://|file|Enterprise%20AJAX_%20Strategies%20for%20Building%20High%20Performance%20Web%20Applications.pdf|4524981|4ff5fe9962ac7fc725d4b26188385886|h=e5jevqspcquqqfjve7z5gvvmxfs3dfzv|/)

**Realm of Racket (EPUB).pdf** (ed2k://|file|Realm%20of%20Racket%20%28EPUB%29.pdf|9174782|f873d66c02656996a75f516342bdd15e|h=bsegqvk6wy46n4qiksjoagisynsjetks|/)

**Critical Thinking.pdf** (ed2k://|file|Critical%20Thinking.pdf|10216705|9db01d44776a52195fc1e4ac3019d966|h=5rod4a2mxuzjx3em43adb3cxgzl7wvou|/)

**Managing Iterative Software Development Projects.chm** (ed2k://|file|Managing%20Iterative%20Software%20Development%20Projects.chm|6581038|986d765cdaf12f49577548017c54bddb|h=nosaot7vqtavlmtptlvddlpu6bt4gemw|/)

**Ubuntu Server最佳方案（一）.pdf** (ed2k://|file|Ubuntu%20Server%E6%9C%80%E4%BD%B3%E6%96%B9%E6%A1%88%EF%BC%88%E4%B8%80%EF%BC%89.pdf|32686445|0490dad8a5facce29f65aeec2ab98980|h=2eeqb4tyce4etbqoutgy2plinml5gesw|/)

**Focus On 2D in Direct3D.pdf** (ed2k://|file|Focus%20On%202D%20in%20Direct3D.pdf|5911207|80a7bb13e694b91c70ccccdd905428af|h=hshycehc2nekcbf74xsymlq4zdrptun5|/)

**Clojure for Domain-specific Languages (EPUB).pdf** (ed2k://|file|Clojure%20for%20Domain-specific%20Languages%20%28EPUB%29.pdf|334210|065bba302697b0cdbd3733a233c0499e|h=p3xuud6pyr6b4zsxrcxwct7ngrd2z2m6|/)

**Thinking In Python.pdf** (ed2k://|file|Thinking%20In%20Python.pdf|851400|a888935ec19d3aa7fcbf3179a1937ee2|h=ptjwuku2ipeavujq6ougkodqnnbk3wvb|/)

**Trends in Functional Programming Volume 6.pdf** (ed2k://|file|Trends%20in%20Functional%20Programming%20Volume%206.pdf|2117183|f7336e406297e559e48a00d676fa88e5|h=quoktrzwyz5akzkob2s6aco4e6gzfqcj|/)

**计算机科学概论(第10版).pdf** (ed2k://|file|%E8%AE%A1%E7%AE%97%E6%9C%BA%E7%A7%91%E5%AD%A6%E6%A6%82%E8%AE%BA%28%E7%AC%AC10%E7%89%88%29.pdf|44939420|d5e01253fb2ca7871bc3c82b80775c50|h=k3r5jawfbduascua2wnr5auur5s5u4uk|/)

**Algebraic Number Theory, Second Edition (Discrete Mathematics and Its Applications).pdf** (ed2k://|file|Algebraic%20Number%20Theory%2C%20Second%20Edition%20%28Discrete%20Mathematics%20and%20Its%20Applications%29.pdf|3175198|f028e38bc3f045ef990529d9a0b84e59|h=2zhcndi3d5paphgzwhd6hzyoetnb6ndm|/)

**Beginning Spring Framework 2.pdf** (ed2k://|file|Beginning%20Spring%20Framework%202.pdf|9740624|70b4df16afdeda26984dbb969b125b7e|h=zyrn2glwicbqqtcw576pzy5w6b34ge3d|/)

**ATL Internals_ Working with ATL 8 (2nd Edition).chm** (ed2k://|file|ATL%20Internals_%20Working%20with%20ATL%208%20%282nd%20Edition%29.chm|4273212|d901e265bb3dda3d2b75fa67d599d48e|h=fsz7cdx4yb6lbbmqju53depcwvnbajtp|/)

**C++ Standard Library.pdf** (ed2k://|file|C%2B%2B%20Standard%20Library.pdf|4801530|f03360f20dcccc4df33fb29c74abee08|h=seqc4uvmvil4qodrbme5fhrk4xae3mcc|/)

**软件随想录.pdf** (ed2k://|file|%E8%BD%AF%E4%BB%B6%E9%9A%8F%E6%83%B3%E5%BD%95.pdf|26682182|188ccdc387fb7215f18a054057e7de24|h=2is25zxoon76vd6qqkindo3k3fhwqfgp|/)

**Project Management Communications Bible.pdf** (ed2k://|file|Project%20Management%20Communications%20Bible.pdf|23236753|5e26c8ac3eb2006196198adaf9abbb1f|h=no63u2e246shki4fpruav66qwo2kr6n5|/)

**SharePoint 2010 Disaster Recovery Guide.pdf** (ed2k://|file|SharePoint%202010%20Disaster%20Recovery%20Guide.pdf|2787225|706413a7847d67957a6e74b6a8ec7378|h=a4idd4365tllpx2d3bl3zleo3k23jt5a|/)

**操作系统概念(第7版)(翻译版)_部分2.pdf** (ed2k://|file|%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F%E6%A6%82%E5%BF%B5%28%E7%AC%AC7%E7%89%88%29%28%E7%BF%BB%E8%AF%91%E7%89%88%29_%E9%83%A8%E5%88%862.pdf|46375675|5d57773e1a3c997b67f369ac55974157|h=mr5vvsb7e34hghlx4mhosg7pi5tx7ygj|/)

**Fonts & Encodings.pdf** (ed2k://|file|Fonts%20%26%20Encodings.pdf|42700765|70c3c618ae2122912f48356257f47dc1|h=wppp6tofuuzmxzeup2eogfhxqryhtxdo|/)

**Rails 4 Application Development HOTSHOT.pdf** (ed2k://|file|Rails%204%20Application%20Development%20HOTSHOT.pdf|6810949|bcc3361fc299292dea211cf7f3ae554b|h=eqmx3pbigv6fzqjzdrfft567s53qxpdt|/)

**HTML5 for Masterminds.pdf** (ed2k://|file|HTML5%20for%20Masterminds.pdf|2985958|c63e2e6ae1ff36e63645789e76be79c3|h=on3fqbu3lc5pjhmbqlrxr2u7qbexf3jg|/)

**Python and AWS Cookbook.pdf** (ed2k://|file|Python%20and%20AWS%20Cookbook.pdf|4812393|7527380bfc5f979636bd6451b2bf3b0e|h=xta5eput26k7565sjudlhxgscjqfcj3l|/)

**windows程序设计（第五版）（中文版）.pdf** (ed2k://|file|windows%E7%A8%8B%E5%BA%8F%E8%AE%BE%E8%AE%A1%EF%BC%88%E7%AC%AC%E4%BA%94%E7%89%88%EF%BC%89%EF%BC%88%E4%B8%AD%E6%96%87%E7%89%88%EF%BC%89.pdf|7614052|44ca02728c1ef048bddea718af3ab49c|h=sqmqkvomnpyzx7si23m6ixf62jidze64|/)

**Automating System Administration with Perl, 2nd Edition.pdf** (ed2k://|file|Automating%20System%20Administration%20with%20Perl%2C%202nd%20Edition.pdf|9789772|5d02b6362568d5fbd54ca391496e245b|h=vmdfdogbz3wjobzmq74rc73ywt3r4zvj|/)

**Expert One-on-One J2EE Design and Development.pdf** (ed2k://|file|Expert%20One-on-One%20J2EE%20Design%20and%20Development.pdf|27530928|22e630304c57a515b3ca89b6f4d9b095|h=lfo2bren46hxv7srwekof2o67lcsj2ax|/)

**简明Python教程.pdf** (ed2k://|file|%E7%AE%80%E6%98%8EPython%E6%95%99%E7%A8%8B.pdf|803696|cacfbf10e8cc41f9d040f5271fc0e751|h=tyarklyyyaykm7swphm5d5jmxbsysqok|/)

**企业集成模式(ZIP卷1).pdf** (ed2k://|file|%E4%BC%81%E4%B8%9A%E9%9B%86%E6%88%90%E6%A8%A1%E5%BC%8F%28ZIP%E5%8D%B71%29.pdf|30408704|72619e3d53e429d94217833c710cd2c1|h=hnbesgjt73kyuhvypnarfjtqwhygiilz|/)

**The CSS3 Anthology.pdf** (ed2k://|file|The%20CSS3%20Anthology.pdf|32953597|a8b6d47379f4499fd6733f4520bfcfe5|h=otuecute2duuaallcbdo5o4rnrrv3t3d|/)

**21天学通C++.pdf** (ed2k://|file|21%E5%A4%A9%E5%AD%A6%E9%80%9AC%2B%2B.pdf|12406601|f81e351b78118767015d7f5727e6cac5|h=rvtigsayjdn7yv3r4vmny7g47gobywvi|/)

**Flash Catalyst CS5 Bible.pdf** (ed2k://|file|Flash%20Catalyst%20CS5%20Bible.pdf|24951673|825879f0e4287b5c557b308da590b2a8|h=ywupvayjzqnkd2xzic6lfqf66aaam3md|/)

**Cassandra Design Patterns.pdf** (ed2k://|file|Cassandra%20Design%20Patterns.pdf|1043730|ce0d586f0044c08d9926e3765c749e88|h=2zmb6mzlzsmnutcgsjyvlcrdy3zmb6nd|/)

**Apache MyFaces 1.2 Web Application Development.pdf** (ed2k://|file|Apache%20MyFaces%201.2%20Web%20Application%20Development.pdf|13890764|baf9b6a6975ad4656fce178bca789711|h=4d4kqsfnfdnyojhw2xxraj25xtt7t4sf|/)

**C 程序设计语言, 第2版.pdf** (ed2k://|file|C%20%E7%A8%8B%E5%BA%8F%E8%AE%BE%E8%AE%A1%E8%AF%AD%E8%A8%80%2C%20%E7%AC%AC2%E7%89%88.pdf|1794005|10d009a4e38b381c7d35967b7073152e|h=lnbaj7xmb3qwjx6avpr4smt6tjodm7qo|/)

**The Official Samba 3.2.x HOW TO and Reference Guide.pdf** (ed2k://|file|The%20Official%20Samba%203.2.x%20HOW%20TO%20and%20Reference%20Guide.pdf|5608148|2af7c6a6439fb52473ff975905667275|h=7tmekgsery5lpzoeipsglegndiywmicd|/)

**Professional Windows Live Programming..pdf** (ed2k://|file|Professional%20Windows%20Live%20Programming..pdf|9897668|68b5a418aaa2a12721e0ac52d80d4dbd|h=ssswslvlxd47327yxw3gporfez4m4kge|/)

**Advanced Windows Script Host Developer’s Guide.pdf** (ed2k://|file|Advanced%20Windows%20Script%20Host%20Developer%E2%80%99s%20Guide.pdf|2599228|7d2d28525e939c56f5b566602ea8e87c|h=u5h3a3pimct4olhzk3qvthkxh6ilnutj|/)

**Sams Teach Yourself Flickr in 10 Minutes.pdf** (ed2k://|file|Sams%20Teach%20Yourself%20Flickr%20in%2010%20Minutes.pdf|8956796|fb65ac0340e2ed78be4c125d6f3b5149|h=7izeccbkfqeq5ehr6rz7b2bmk63fod2o|/)

**Foundations of SQL Server 2008 R2 Business Intelligence.pdf** (ed2k://|file|Foundations%20of%20SQL%20Server%202008%20R2%20Business%20Intelligence.pdf|47142484|5e00ec46857c398274f05538399fe809|h=fuihb4udhgb4splpv67nlj6skanvcfaf|/)

**Elements of Computer Security.pdf** (ed2k://|file|Elements%20of%20Computer%20Security.pdf|7263690|2b6ba1b65ae911047ba04e7f6aefa9be|h=riqdrz2tuusg5v7b73hjq4b24hn5yy6u|/)

**View Updating and Relational Theory.pdf** (ed2k://|file|View%20Updating%20and%20Relational%20Theory.pdf|19818675|7c24a64422cdcce2b8e508e6ec20d820|h=i7jmu7otqcu3kuvg4oraxxz3pf2fhw5t|/)

**Eclipse in Action.pdf** (ed2k://|file|Eclipse%20in%20Action.pdf|5831138|60d6bb77b01e4aa465fc5a37ad37641e|h=wiv73fwddqmw67fsbyndwikq4tui4kik|/)

**Professional Microsoft SQL Server 2008 Programming.pdf** (ed2k://|file|Professional%20Microsoft%20SQL%20Server%202008%20Programming.pdf|11944156|7262b62a523c31eb1ef868fec2372db6|h=vgm3zj7g4jhtwar72ynnapz7esbxtxhz|/)

**Beginning Android C++ Game Development.pdf** (ed2k://|file|Beginning%20Android%20C%2B%2B%20Game%20Development.pdf|4965769|5a2ab55911991e1a64a257bfdc964c0f|h=6d6xj237muptbvvyvyy5xal5eedva3sf|/)


