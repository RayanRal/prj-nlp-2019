# lisp-bot
Mark Thuckerbot


## Node Signatures
All nodes have value, uuid, docs.

- Number
- String
- List
- Ref: Value points to referenced uuid.
- Function: argNames, scope, macroScope, isMacro

