## Code of conduct
Welcomes any kind of contribution, please follow the [how to write GO code](https://golang.org/doc/code.html)  
