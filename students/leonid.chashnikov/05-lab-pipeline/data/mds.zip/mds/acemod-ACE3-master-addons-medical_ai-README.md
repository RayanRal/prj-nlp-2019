ace_medical_ai
==========

Makes AI units heal themselves and each other.

## Maintainers

The people responsible for merging changes to this component or answering potential questions.

- [BaerMitUmlaut](https://github.com/BaerMitUmlaut)

